package com.xd.powercatsence;

import java.util.Map;
import java.util.TreeMap;

public class CpuFullSpeedSence extends SenceThread{

	private String senceName = "CPUȫ�ټ���";
	
	public static final int INT_C = 2000000;  
    public static final int DOU_C = 500000;  
    public static final int MAIN_C = 10000;    
     
    public static final String intWork = "int";
    public static final String doubleWork = "double";
    
    private String workId = intWork;
    
    public int workInt() {  
    	int m_i = 0; 
        for (int i=1;i<= INT_C;i++) {  
            m_i = (~(i*7) + 0x963 - i) & (i / 3);  
        }  
        return m_i;
    }  
      
    public double workDouble() {  
    	double m_d = 0;
        for (int i=1;i<= DOU_C;i++) {  
            m_d = ((i<<2) + 0.36954) * Math.sin((double)i);  
        }  
        return m_d;
    } 
    
    
	@Override
	void worker() throws InterruptedException {
		while(isRun){
			if (workId.equals(intWork)) {
				workInt();
			}
			if (workId.equals(doubleWork)) {
				workDouble();
			}
			super.callOnChange();
		}
	}

	@Override
	void config(String str) {
		Map<String, String> map = MapUtil.stringToMap(str);
		if (map!=null) {
			configMap(map);
			String val = map.get("workId");
			if (val!=null) {
				workId = val;
			}
		}
	}

	@Override
	String getSenceName() {
		return senceName;
	}

	@Override
	String getConfig() {
		Map<String, String> map = new TreeMap<String, String>();
		getConfigMap(map);
		map.put("workId", ""+workId);
		String str = MapUtil.mapToString(map);
		return str;
	}

	@Override
	String getInfo() {
		return getConfig();
	}

}
