package com.xd.powercatsence;

import java.util.Map;
import java.util.TreeMap;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

    protected static final String TAG = "MainActivity";
    CpuFullSpeedSence cpuFullWork;
    MemFullSpeedSence memFullWrok;
    TcpDownSence tcpDownWork;
    
    SenceView cpuFullSence;
    SenceView memFullSence;
    SenceView tcpDownSence;
    
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        cpuFullSence = (SenceView) findViewById(R.id.cpufull_sence);
        cpuFullWork = new CpuFullSpeedSence();
        cpuFullSence.bindSenceThread(cpuFullWork);
        
        memFullSence = (SenceView) findViewById(R.id.memfull_sence);
        memFullWrok = new MemFullSpeedSence();
        memFullSence.bindSenceThread(memFullWrok);
        
        tcpDownSence = (SenceView) findViewById(R.id.tcpdown_sence);
        tcpDownWork = new TcpDownSence();
        tcpDownSence.bindSenceThread(tcpDownWork);
        
    }

}
