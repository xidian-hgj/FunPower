package com.xd.powercatsence;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.TreeMap;

import android.util.Log;
import android.widget.Space;

public class TcpDownSence extends SenceThread {

	private String senceName = "TCP����";

	int port = 4002;
	String site = "192.168.2.100";
	int sendBf_Max = 1024 * 128;
	byte[] senderBuffer;
	long downNum = 0;
	long lastRunTime = 0;

	@Override
	void worker() throws InterruptedException {
		senderBuffer = new byte[sendBf_Max];
		
		while (isRun) {
			Socket socket = null;
			InputStream is = null;
			try {
				socket = new Socket(site, port);
				is = socket.getInputStream();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			try {
				int num = 0;
				while(isRun){
					num += is.read(senderBuffer, 0, senderBuffer.length);
					if (getRunedTime() > (lastRunTime + 200)) {
						super.callOnChange();
						super.callOnInfo();
						lastRunTime = getRunedTime();
						downNum = num;
						num = 0;
					}
					
				}
			} catch (Exception e) {
				Log.i(TAG, "socket close");
			}
			
			try {
				is.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	void config(String str) {
		Map<String, String> map = MapUtil.stringToMap(str);
		String val;
		if (map != null) {
			configMap(map);
			val = map.get("port");
			if (val != null) {
				port = Integer.parseInt(val);
			}
			val = map.get("site");
			if (val != null) {
				site = val;
			}
		}
	}

	@Override
	String getSenceName() {
		return senceName;
	}

	@Override
	String getConfig() {
		Map<String, String> map = new TreeMap<String, String>();
		getConfigMap(map);
		map.put("port", "" + port);
		map.put("site", "" + site);
		String str = MapUtil.mapToString(map);
		return str;
	}

	@Override
	String getInfo() {
		return "num=" + downNum + "  time=" + (getRunedTime() - lastRunTime);
	}

}
