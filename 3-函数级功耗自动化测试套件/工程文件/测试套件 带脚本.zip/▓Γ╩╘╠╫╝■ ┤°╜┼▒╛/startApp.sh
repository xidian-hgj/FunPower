#! /system/bin/sh

name=com.xd.powercatsence
activity=MainActivity
#执行时间为 workTime*用例个数
#现阶段用例个数=3
workTime=5000		

echo "Android program is starting"	
am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -e workTime ${workTime} -n ${name}/.${activity} >> /dev/null

