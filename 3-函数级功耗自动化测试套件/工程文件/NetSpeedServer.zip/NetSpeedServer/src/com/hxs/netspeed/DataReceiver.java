package com.hxs.netspeed;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class DataReceiver {

	int port;
	ServerSocket serverSocket;
	Thread receiverThread;
	boolean isReceiverRun = false;
	
	int recBf_Max = 0;
	int recBf_Num = 0;
	byte[] receiverBuffer;
	
	public DataReceiver(int port, int buffer_Max) {	
		this.port = port;
		recBf_Max = buffer_Max;
		receiverBuffer = new byte [recBf_Max];
	}

	public void start(){
		try {
			isReceiverRun = true;
			serverSocket = new ServerSocket(port);
			receiverThread = new Thread(recive);
			receiverThread.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void stop() {
		isReceiverRun = false;
		if (receiverThread != null) {
			receiverThread.interrupt();
			receiverThread = null;
			try {
				serverSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	Runnable recive = new Runnable() {
		public void run() {
			while (isReceiverRun) {
				try {
					recBf_Num = 0;
					Socket socket = serverSocket.accept();
					InputStream is = socket.getInputStream();
					do {
						int num = is.read(receiverBuffer, recBf_Num, receiverBuffer.length-recBf_Num);
						if (num == -1) {
							break;
						}else {
							recBf_Num += num;
						}
					} while (true);
					
					System.out.println("received data num: "+recBf_Num);
					socket.close();

				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	};

}
