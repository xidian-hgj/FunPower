package com.hxs.netspeed;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class DataSender {

	int port;
	ServerSocket serverSocket;
	Thread sendThread;
	boolean isSendRun = false;

	static int[] upSpeed = { 1, 10, 50, 80, 128, 200, 512, 1024, 2048, 4096,
			6144, 10240, 20480, 40960, 61440, 102400, 204800, 409600, 819200 };
	static int upSpeedIndex;

	int sendBf_Max = 0;
	int sendBf_Num = 0;
	byte[] senderBuffer;

	public DataSender(int port, int buffer_Max) {
		this.port = port;
		sendBf_Max = buffer_Max;
		senderBuffer = new byte[sendBf_Max];
		new Timer().schedule(new speedChange(), 0, 5000);
	}

	public void start() {
		try {
			isSendRun = true;
			serverSocket = new ServerSocket(port);
			sendThread = new Thread(recive);
			sendThread.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void stop() {
		isSendRun = false;
		if (sendThread != null) {
			sendThread.interrupt();
			sendThread = null;
			try {
				serverSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	Runnable recive = new Runnable() {
		public void run() {
			while (isSendRun) {

				Socket socket = null;
				OutputStream os = null;
				try {
					socket = serverSocket.accept();
					os = socket.getOutputStream();
				} catch (IOException e) {
					e.printStackTrace();
				}

				try {
					while (true) {
						os.write(senderBuffer, 0, upSpeed[upSpeedIndex]);
						System.out.println("sended data num: " + upSpeed[upSpeedIndex]);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				} catch (IOException e) {
					System.out.println("write error");
				}
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	};

	class speedChange extends TimerTask {
		@Override
		public void run() {
			upSpeedIndex++;
			if (upSpeedIndex == upSpeed.length) {
				upSpeedIndex = 0;
			}
			System.out
					.println("sended speed changed: " + upSpeed[upSpeedIndex]);
		}
	}
}
