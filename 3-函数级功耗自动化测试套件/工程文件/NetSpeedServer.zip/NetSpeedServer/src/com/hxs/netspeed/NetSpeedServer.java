package com.hxs.netspeed;

import java.io.IOException;
import java.nio.ByteBuffer;


public class NetSpeedServer {


	static DataReceiver receiver = new DataReceiver(4001, 1000000);
	static DataSender sender = new DataSender(4002, 1000000);
	
	public static void main(String[] args) throws IOException {
		
		
		receiver.start();
		System.out.println("receiver started");
		
		sender.start();
		System.out.println("sender started");
		
		while (true) {

		}
	}
}
