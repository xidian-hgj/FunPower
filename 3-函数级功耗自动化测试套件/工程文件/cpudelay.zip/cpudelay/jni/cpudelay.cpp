#include <cerrno>
#include <cstddef>

int main(void)
{
    while(1);
}

